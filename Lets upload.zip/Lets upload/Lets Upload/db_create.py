#!/usr/bin/python3
from app import db

db.create_all()
